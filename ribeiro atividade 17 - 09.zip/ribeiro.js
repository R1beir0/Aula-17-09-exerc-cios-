/*const primeiroValor = 3 
const segundoValor = 4
const resultado = primeiroValor + segundoValor 
console.log(resultado)*/

/*const primeiroValor = 3
const segundoValor = 5
const resultado = primeiroValor * segundoValor
console.log(resultado)*/

/*const primeiroValor = 15
const segundoValor = 2
const resultado = primeiroValor / segundoValor
console.log(resultado)*/

/*const primeiroValor = 2
const segundoValor = 1

const resultado = primeiroValor === segundoValor
console.log(resultado)
false*/

/*const primeiroValor = 2 
const segundoValor = 1

const resultado = primeiroValor !== segundoValor

console.log(resultado)
true*/

/*const primeiroValor = 2
const segundoValor = 1
const resultado = primeiroValor > segundoValor

console.log(resultado)
true*/

/*const primeiroValor = 2
const segundoValor = 1
const resultado =primeiroValor < segundoValor
console.log(resultado)
false*/

/*let a = 10
let b = 15 
console.log(a === b)*/


/*const a = true
const b = false
const c = true

console.log(a && b) false*/

/*const a = true
const b = false
const c = true
console.log(b && c) false*/

/*const a = true
const b = false
const c = true
console.log(a && c) true*/

/*const a = true
const b = false
const c = true
console.log(a && b && c) false*/



/*const a = true 
const b = false
const c = true 

console.log(a||b)
true*/

/*const a = true 
const b = false
const c = true 
console.log(b||c)
true*/

/*const a = true 
const b = false
const c = true 
console.log(a||c)
true*/

/*const a = true 
const b = false
const c = true 
console.log(a||b||c)
true */

const nome = prompt("Qual é o seu nome?")
const anoNascimento = Number(prompt("Qual o seu ano de nascimento?"))
let anoAtual = Number(prompt("Qual o ano atual?")) 
let maiorIdade = false

 console.log("Nome:", nome)
console.log("Idade:", anoAtual - anoNascimento)
console.log("É maior de idade?", maiorIdade)



console.log("Idade em 2050:", 2050 - anoNascimento, "anos de idade")











